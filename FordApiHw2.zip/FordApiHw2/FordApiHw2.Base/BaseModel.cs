﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Xml.Linq;

namespace FordApiHw2.Base;
[Table("BASEMODEL")]

public abstract class BaseModel
{
    [Column("ID")]
    public int Id { get; set; }

    [Column("CREATEDAT")]
    [Display(Name = "Created At")]
    public DateTime CreatedAt { get; set; }

    [Column("CREATEDBY")]
    [MaxLength(500)]
    [Display(Name = "Created By")]
    public string CreatedBy { get; set; }
}