﻿using FordApiHw2.Base;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FordApiHw2.Data.Entitites;
[Table("ACCOUNT")]
public class Account : BaseModel
{
    [Required]
    [MaxLength(125)]
    [Display(Name = "User Name")]
    [Column("USERNAME")]
    public string UserName { get; set; }

    [Required]
    [Column("PASSWORD")]
    public string Password { get; set; }

    [Required]
    [MaxLength(500)]
    [Column("NAME")]
    public string Name { get; set; }

    [Required]
    [EmailAddressAttribute]
    [MaxLength(500)]
    [Column("EMAIL")]
    public string Email { get; set; }

    [Required]
    [Column("ROLE")]
    public string Role { get; set; }


    [Display(Name = "Last Activity")]
    [Column("LAST_ACTIVITY")]
    public DateTime LastActivity { get; set; }
    public Person? Person { get; set; }

}