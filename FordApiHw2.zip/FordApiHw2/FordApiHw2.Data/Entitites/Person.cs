﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using FordApiHw2.Base;
namespace FordApiHw2.Data.Entitites;
[Table("PERSON")]
public class Person : BaseModel
{
    [Required]
    [MaxLength(25)]
    [Display(Name = "Staff Id")]
    [Column("ACCOUNTID")]
    public string AccountId { get; set; }

    [Required]
    [MaxLength(500)]
    [Display(Name = "First Name")]
    [Column("FIRSTNAME")]
    public string FirstName { get; set; }

    [Required]
    [MaxLength(500)]
    [Display(Name = "Last Name")]
    [Column("LASTNAME")]
    public string LastName { get; set; }

    [EmailAddress]
    [MaxLength(500)]
    [Column("EMAIL")]
    public string Email { get; set; }

    [MaxLength(500)]
    [Column("DESCRIPTION")]
    public string Description { get; set; }

    [Phone]
    [MaxLength(25)]
    [Column("PHONE")]
    public string Phone { get; set; }

    [Required]
    [DataType(DataType.Date)]
    [Display(Name = "Date Of Birth")]
    [Column("DATEOFBIRTH")]
    public DateTime DateOfBirth { get; set; }

    public Account? Account { get; set; } //one to one



}