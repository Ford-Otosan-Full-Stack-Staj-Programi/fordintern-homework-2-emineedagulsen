﻿using System.ComponentModel.DataAnnotations;

namespace FordApiHw2.Data.Token;
public class UpdatePasswordRequest
{
    [Required]
    public string OldPassword { get; set; }

    [Required]
    public string NewPassword { get; set; }
}