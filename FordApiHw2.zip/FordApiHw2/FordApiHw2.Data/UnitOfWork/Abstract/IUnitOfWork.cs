﻿using FordApiHw2.Data.Entitites;
using FordApiHw2.Data.Repository.Abstract;
namespace FordApiHw2.Data.UnitOfWork.Abstract;
//IDisposable ==> Unit of work işi bittiği zaman kendisi oto olarak silinsin
public interface IUnitOfWork : IDisposable
{
    //Bu neden??
    IGenericRepository<Person> PersonRepository { get; }
    IGenericRepository<Account> AccountRepository { get; }

    void CompleteWithTransaction();
    void Complete();
}