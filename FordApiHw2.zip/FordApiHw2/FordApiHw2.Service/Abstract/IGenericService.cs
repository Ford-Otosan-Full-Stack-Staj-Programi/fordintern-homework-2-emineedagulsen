﻿namespace FordApiHw2.Services.Abstract;
public interface IGenericService<T> where T : class
{
    List<T> GetAll();
    public void Add(T entity);
    T GetById(int id);
    void Update(T entity);
    void Remove(int id);
}
