﻿using FordApiHw2.Data.Token;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FordApiHw2.Service.Abstract;

public interface ITokenManagementService
{
    TokenResponse GenerateToken(TokenRequest request);
}
