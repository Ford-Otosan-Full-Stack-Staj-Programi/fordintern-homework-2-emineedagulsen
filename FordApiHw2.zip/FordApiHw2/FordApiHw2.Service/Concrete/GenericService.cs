﻿using FordApiHw2.Data.Repository.Abstract;
using FordApiHw2.Data.UnitOfWork.Abstract;
using FordApiHw2.Data.UnitOfWork.Concrete;
using FordApiHw2.Services.Abstract;

namespace FordApiHw2.Services.Concrete;
public class GenericService<T> : IGenericService<T> where T : class
{
    private readonly IGenericRepository<T> _repository;
    private readonly IUnitOfWork _unitOfWork;
    public GenericService(IGenericRepository<T> repository, IUnitOfWork unitOfWork)
    {
        _repository = repository;
        _unitOfWork = unitOfWork;
    }
    public List<T> GetAll()
    {
        return _repository.GetAll();
    }
    public void Add(T entity)
    {
        _repository.Add(entity);
        _unitOfWork.Complete();
    }
    public T GetById(int id)
    {
        return _repository.GetById(id);
    }

    public void Update(T entity)
    {
        _repository.Update(entity);
        _unitOfWork.Complete();
    }

    public void Remove(int id)
    {
        var staff = _repository.GetById(id);
        if (staff != null)
        {
            _repository.Remove(id);
            _unitOfWork.Complete();
        }
    }
}