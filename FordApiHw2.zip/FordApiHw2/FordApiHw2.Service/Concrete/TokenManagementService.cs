﻿using FordApiHw2.Data.Token;

namespace FordApiHw2.Service.Concrete;

public interface TokenManagementService
{
    TokenResponse GenerateToken(TokenRequest request);
}