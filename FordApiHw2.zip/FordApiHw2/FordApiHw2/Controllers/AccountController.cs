﻿using FordApiHw2.Data.Entitites;
using FordApiHw2.Services.Abstract;
using FordApiHw2.Services.Concrete;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using System.Security.Claims;

namespace FordApiHw2.Controllers;

[Route("ford/api/v1.0/[controller]")]
[ApiController]
public class AccountController : ControllerBase
{
    private readonly IGenericService<Account> service;
    public AccountController(IGenericService<Account> service)
    {
        this.service = service;
    }


    [HttpGet]
    [Authorize]
    public List<Account> GetAll()
    {
        Log.Debug("AccountController.GetAll");
        var response = service.GetAll();
        return response;
    }
    [HttpGet("{id}")]
    [Authorize]
    public Account GetById([FromRoute] int id)
    {
        Log.Debug("AccountController.GetById");
        var response = service.GetById(id);
        return response;
    }
    [Authorize]
    [HttpPost]
    public void Post([FromBody] Account request)
    {
        service.Add(request);
    }

    [HttpPut("{id}")]
    [Authorize]
    public void Put([FromBody] Account request)
    {
        service.Update(request);
    }

    [HttpDelete("{id}")]
    [Authorize]
    public void Delete(int id)
    {
        service.Remove(id);
    }



}