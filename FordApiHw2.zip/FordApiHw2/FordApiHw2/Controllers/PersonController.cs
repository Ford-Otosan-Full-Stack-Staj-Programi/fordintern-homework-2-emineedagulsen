﻿using FordApiHw2.Data.Entitites;
using FordApiHw2.Services.Abstract;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using System.Security.Claims;

namespace FordApiHw2.Controllers;

[Route("ford/api/v1.0/[controller]")]
[ApiController]
public class PersonController : ControllerBase
{
    private readonly IGenericService<Person> service;
    private readonly IHttpContextAccessor httpContextAccessor;

    public PersonController(IGenericService<Person> service, IHttpContextAccessor httpContextAccessor)
    {
        this.service = service;
        this.httpContextAccessor = httpContextAccessor;
    }

    [Authorize]
    [HttpGet]
    // [ResponseCache(CacheProfileName = "Duration45")]
    //[ResponseCache(Duration = 60, Location = ResponseCacheLocation.Any, NoStore = false)]
    [Authorize]
    [HttpGet]
    public List<Person> GetAll()
    {
        var accountId = httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        var response = service.GetAll().Where(p => p.AccountId == accountId).ToList();
        return response;
    }

    [HttpGet("{id}")]
    [Authorize]
    public Person GetById(int id)
    {
        var accountId = httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        var response = service.GetById(id);
        if (response.AccountId != accountId)
        {
            // Handle unauthorized access
            throw new UnauthorizedAccessException();
        }
        return response;
    }

    [Authorize]
    [HttpPost]
    public void Post([FromBody] Person request)
    {
        var accountId = httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        request.AccountId = accountId;
        service.Add(request);
    }

    [Authorize]
    [HttpPut("{id}")]
    public void Put([FromBody] Person request)
    {
        var accountId = httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (request.AccountId != accountId)
        {
            // Handle unauthorized access
            throw new UnauthorizedAccessException();
        }
        service.Update(request);
    }

    [Authorize]
    [HttpDelete("{id}")]
    public void Delete(int id)
    {
        var accountId = httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        var person = service.GetById(id);
        if (person.AccountId != accountId)
        {
            // Handle unauthorized access
            throw new UnauthorizedAccessException();
        }
        service.Remove(id);
    }

}