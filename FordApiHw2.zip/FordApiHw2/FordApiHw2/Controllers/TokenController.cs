﻿using FordApiHw2.Data.Token;
using FordApiHw2.Service.Abstract;
using Microsoft.AspNetCore.Mvc;

namespace FordApiHw2.Controllers;

[Route("ford/api/v1.0/[controller]")]
[ApiController]
public class TokenController : ControllerBase
{
    private readonly ITokenManagementService tokenManagementService;
    public TokenController(ITokenManagementService tokenManagementService)
    {
        this.tokenManagementService = tokenManagementService;
    }


    [HttpPost]
    public TokenResponse Login([FromBody] TokenRequest request)
    {
        var response = tokenManagementService.GenerateToken(request);
        return response;
    }


}