using FordApiHw2.Data.Context;
using FordApiHw2.Data.Repository.Abstract;
using FordApiHw2.Data.Repository.Concrete;
using FordApiHw2.Data.UnitOfWork.Abstract;
using FordApiHw2.Data.UnitOfWork.Concrete;
using FordApiHw2.Service.Abstract;
using FordApiHw2.Service.Concrete;
using FordApiHw2.Services.Abstract;
using FordApiHw2.Services.Concrete;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
// Add services to the container.
var configuration = new ConfigurationBuilder()
.AddJsonFile("appsettings.json")
    .Build();
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseOracle(configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddControllersWithViews();
builder.Services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));
builder.Services.AddScoped(typeof(IGenericService<>), typeof(GenericService<>));
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();
builder.Services.AddHttpContextAccessor();
//kimlik do�rulama �emas� yap
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Home/Login/";
        options.AccessDeniedPath = "/Home/Login/";
        //kullan�c�n�n son etkile�iminden itibaren belirtilen s�re i�inde sayfa yenilemesi yaparak
        //oturumunun yenilenmesi sa�lan�r.
        options.SlidingExpiration = true;
    });


//builder.Services.AddScoped(typeof(IGenericService<>), typeof(GenericService<>));
// Swagger/OpenAPI support
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
var app = builder.Build();
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseHttpsRedirection();
app.UseRouting();
app.UseAuthorization();
app.MapControllers();g
app.UseAuthentication(); // middleware
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});
app.Run();